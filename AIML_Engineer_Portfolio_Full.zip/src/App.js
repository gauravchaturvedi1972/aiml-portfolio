import './styles.css';
export default function App(){
 return (
  <div>
   <h1>AIML Engineer Portfolio</h1>
   <p>Production-ready starter structure.</p>
  </div>
 );
}